package com.example.homework20191112;

public class Bird {

    public String birdname;
    public String zipcode;
    public String name;

    public Bird() {
    }

    public Bird(String birdname, String zipcode, String name) {
        this.birdname = birdname;
        this.zipcode = zipcode;
        this.name = name;
    }
}
